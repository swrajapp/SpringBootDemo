package com.dev.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.dev.model.Book;
import com.dev.model.Library;
import com.dev.service.LibraryService;



@Controller
public class ControllerClass {
	
	@Autowired
	LibraryService libraryService;
	
	
	@RequestMapping("/")
	public void home()
	{
		System.out.println("Library-book Service");
	}
	
	@RequestMapping("/home")
	public String index()
	{
		System.out.println("index");
		return "index.jsp";
	}
	
	@RequestMapping(value="/addBook",method=RequestMethod.POST)
	public ModelAndView addBook(Library library,Book book)
	{			
		ModelAndView modelview=new ModelAndView("Addsuccess.jsp");
		book.setLibrary(library);
		library.getBook().add(book);	
		Library library2=libraryService.add(library);
		modelview.addObject(library2);
		return modelview;
		
	}
	
	@RequestMapping(value="/deleteBook",method=RequestMethod.GET)
	public String deleteBook(@RequestParam int libraryId) 
	{
		libraryService.deleteBook(libraryId);
		return "Deletesuccess.jsp";
	}
	
	@RequestMapping(value="/searchBook",method=RequestMethod.GET)
	public ModelAndView searchBook(@RequestParam int libraryId,@RequestParam int bookId) 
	{
		ModelAndView modelview=new ModelAndView("Searchsuccess.jsp");
		Library library=libraryService.findBook(libraryId);
		Book book=libraryService.findBookId(bookId);
		modelview.addObject(library);
		modelview.addObject(book);
		return modelview;
	}
		
	
	@RequestMapping(value="/updateBook",method=RequestMethod.POST)
	public ModelAndView updateBook(@RequestParam int bookId,@RequestParam String bookName,@RequestParam String author,@RequestParam String publisher) 
	{
		ModelAndView modelview=new ModelAndView("Updatesuccess.jsp");
		Book book=libraryService.updateBookDetails(bookId,bookName,author,publisher);
		modelview.addObject(book);
		return modelview;
	}
	
	@RequestMapping(value="/add",method=RequestMethod.POST)
	public String add(@RequestParam int libraryId,@RequestParam String libraryName,Book book)
	{
		Library library=libraryService.findBook(libraryId);
		library.setLibraryName(libraryName);		
		book.setLibrary(library);
		library.getBook().add(book);
		libraryService.add(library);
		return "Addsuccess.jsp";
	
	}


}
