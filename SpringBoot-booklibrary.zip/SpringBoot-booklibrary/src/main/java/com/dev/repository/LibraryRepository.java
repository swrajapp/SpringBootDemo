package com.dev.repository;


import org.springframework.data.repository.CrudRepository;

import com.dev.model.Library;

public interface LibraryRepository extends CrudRepository<Library , Integer>{

}
