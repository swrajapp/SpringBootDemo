package com.dev.service;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dev.model.Book;
import com.dev.model.Library;
import com.dev.repository.BookRepository;
import com.dev.repository.LibraryRepository;

@Service
public class LibraryService {
	
	@Autowired
	LibraryRepository libraryRepository;
	
	@Autowired
	BookRepository bookRepository;
	
	public Library add(Library library)
	{
		return libraryRepository.save(library);
		
	}
	
	public void deleteBook(Integer libraryId)
	{
		Library l =findBook(libraryId);
		libraryRepository.delete(l);
	}

	public Library findBook(Integer libraryId) { 
		
		Optional<Library> optional =libraryRepository.findById(libraryId);
		Library library=optional.get();
		return library;
		
	}
	

	
	public Book findBookId(Integer bookId) { 
		
		
		Optional<Book> optional =bookRepository.findById(bookId);
		Book book=optional.get();
		return book;
							 
}

public Book updateBookDetails(int nbId, String nBName, String nBauthr, String nBpubshr) {
	
	Book b =findBookId(nbId);
	
    b.setBookName(nBName);
	b.setAuthor(nBauthr);
	b.setPublisher(nBpubshr);
	bookRepository.save(b);
	return b;
}



}